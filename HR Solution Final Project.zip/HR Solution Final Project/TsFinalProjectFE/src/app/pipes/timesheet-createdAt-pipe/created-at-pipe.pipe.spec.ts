import { CreatedAtPipePipe } from './created-at-pipe.pipe';

describe('CreatedAtPipePipe', () => {
  it('create an instance', () => {
    const pipe = new CreatedAtPipePipe();
    expect(pipe).toBeTruthy();
  });
});
