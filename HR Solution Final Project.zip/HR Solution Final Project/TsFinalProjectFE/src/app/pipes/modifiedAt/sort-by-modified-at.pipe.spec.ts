import { SortByModifiedAtPipe } from './sort-by-modified-at.pipe';

describe('SortByModifiedAtPipe', () => {
  it('create an instance', () => {
    const pipe = new SortByModifiedAtPipe();
    expect(pipe).toBeTruthy();
  });
});
