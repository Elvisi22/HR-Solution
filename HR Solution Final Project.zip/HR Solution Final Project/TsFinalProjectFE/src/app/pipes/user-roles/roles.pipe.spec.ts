import { RolesPipe } from './roles.pipe';

describe('RolesPipe', () => {
  it('create an instance', () => {
    const pipe = new RolesPipe();
    expect(pipe).toBeTruthy();
  });
});
