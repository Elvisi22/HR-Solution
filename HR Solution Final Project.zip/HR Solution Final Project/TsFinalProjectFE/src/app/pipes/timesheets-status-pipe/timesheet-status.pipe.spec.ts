import { TimesheetStatusPipe } from './timesheet-status.pipe';

describe('TimesheetStatusPipe', () => {
  it('create an instance', () => {
    const pipe = new TimesheetStatusPipe();
    expect(pipe).toBeTruthy();
  });
});
