package com.ts.tsProject.enums;

public enum UserType {
    USER,
    MANAGER
}


