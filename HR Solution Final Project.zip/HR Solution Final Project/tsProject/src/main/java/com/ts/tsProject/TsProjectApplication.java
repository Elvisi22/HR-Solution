package com.ts.tsProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsProjectApplication.class, args);
	}

}
