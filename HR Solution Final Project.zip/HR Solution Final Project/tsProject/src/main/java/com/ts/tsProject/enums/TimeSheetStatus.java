package com.ts.tsProject.enums;

public enum TimeSheetStatus {
    ACCEPTED,
    PENDING,
    REJECTED
}
